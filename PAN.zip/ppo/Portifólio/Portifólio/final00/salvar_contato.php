<?php
// Conexão com o banco
$servername = "localhost";
$username = "root"; // padrão do XAMPP
$password = ""; // se você definiu senha, coloque aqui
$dbname = "contato"; // nome do seu banco de dados

$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Pegar dados do formulário
$nome = $_POST['nome'];
$email = $_POST['email'];
$assunto = $_POST['assunto'];
$mensagem_txt = $_POST['mensagem'];
$contato = $_POST['contato'];
$telefone = $_POST['telefone'];

// Inserir no banco
$sql = "INSERT INTO contatos (nome, email, assunto, mensagem_txt, contato, telefone)
        VALUES ('$nome', '$email', '$assunto', '$mensagem_txt', '$contato', '$telefone')";

if ($conn->query($sql) === TRUE) {
    echo "<h2>Mensagem enviada com sucesso!</h2>";
    echo "<a href='contato.html'>Voltar</a>";
} else {
    echo "Erro: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
